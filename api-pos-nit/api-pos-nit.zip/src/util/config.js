module.exports = {
  config: {
    app_name: "POS-NIT",
    app_versoin: "1.0",
    image_path: "C:/xampp/htdocs/fullstack/image_pos/",
    db: {
      HOST: "localhost",
      USER: "root",
      PASSWORD: "",
      DATABASE: "pos-nit",
      PORT: 6306,
    },
    token: {
      access_token_key:
        "#$*%*(*234898ireiuLJEROI#@)(#)$*@#)*$(@948858839798283838jaflke",
    },
  },
};
