import React from "react";

function RegisterPage() {
  return (
    <div>
      <h1>RegisterPage</h1>
    </div>
  );
}

export default RegisterPage;
