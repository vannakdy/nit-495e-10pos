import React from "react";

function EmployeePage() {
  return (
    <div>
      <h1>Employee</h1>
    </div>
  );
}

export default EmployeePage;
