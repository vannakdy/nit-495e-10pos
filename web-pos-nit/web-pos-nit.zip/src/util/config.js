export const Config = {
  base_url: "http://localhost:8081/api/",
  version: "1.0",
  token: "",
};
